eigensoft
=========

This was an experimental speedup to (and Mac/Windows port of) EIGENSOFT 5.
It's rendered mostly obsolete by the greater speedup delivered by EIGENSOFT 6's
"fastmode" randomized approximation algorithm, but the precompiled Mac/Windows
binaries may still come in handy.


EIGENSOFT is copyright by Harvard University and The Broad Institute; see http://www.hsph.harvard.edu/alkes-price/software/ for more details.
