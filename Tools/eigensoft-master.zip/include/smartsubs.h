void setoutliermode(int mode) ;
int
ridoutlier(double *evecs, int n, int neigs, 
 double thresh, int *badlist, OUTLINFO **outinfo)  ;

